﻿namespace ATOLL_3;

public class AntennaArray{
        
    public string name {get; private set;}
    public string text {get; private set;}
    public string NbAntennes {get; private set;}
    public bool Type {get; private set;}
    public List<string> splited {get; private set;} = null;
    public void SetAntennaArray(string text)
    {
        this.text=text;
        this.splited=new List<string>(text.Split(new char[]{'\n','\t',':','\r','(',')'}));
        
        this.splited.RemoveAll(EstVide);     
        
        this.name= this.splited[0].Trim();
        this.NbAntennes= this.splited[2].Trim();
        
        if(this.splited[4].Trim()=="1"){
            this.Type=true;
        }else{
            this.Type=false;
        }

    }

    private static bool EstVide(string s){return s=="";}
}