namespace ATOLL_3;

public class Point
    {
        public double XValue { get; set; }
        public double YValue { get; set; }
    }